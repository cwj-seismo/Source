'''
CWJ 22JUN2018
README
The functions below are pulled from a python object I wrote to generate the input 
file for the vertical force code. The inputs are the force applied from the water 
load. Use the area of the grid cell when inverting for the water storage and the 
height of the water to get a volume. With water density and gravity get the 
vertical force.
For the Green's functions, scale the spherical harmonics to the grid spacing. In 
California the grid spacing was 0.25 deg and I was using 3200 harmonics 
correspondnig to 25km resolution. The source location and the observation location 
must not be equal. To ensure the source grid and observation grid are different I 
applied a 2.5 km perturbation to the observatoin location. If they are equal the 
code will error. This code is modified from stat2A for the elastic deformation 
from a fault. In the vertical force version, the force is applied as a small finite 
line source at the surface. I have compared the results with oter codes and they 
are consistent with this implementation. 

To get the stress at the time of each earthquake I generate a strain tensor time 
series using the GPS derived water storage with obervation points on a 25 km grid. 
Each earhquake is assigned the strain tensor closest in space and time. This is much 
less computationally expensive than using the observation location of every 
earthquake in the catalog and the values at depth to not vary greatly for nearby 
earthquake locations or adjacent time steps.

To convert the strain to stress I use the simple linear elastic relationship with 
a shear modulus of 35 GPa and Poisson ratio of 0.25. For this large scale I do not 
have spatially varying elastic properties. In hindsight I would leave everything in 
strain but the results in stress are easier to inpertpret and present than strain values.

################

To modify for matlab use the following input variables to repalce values 
contained in 'self'
filename - use the date of the GPS derived water storage. The fortran routine 
        I use is modified to accept a filename so many files can be run at once 
        in one directory

dlon - spacing distance in longitude of water storage: This is converted to 
        meters for area calculatoin
dlat - spacing distance in latitude of water storage: This is converted to 
        meters for area calculation
dz - water storage in meters
rho - density of water
g - gravity
The code wants a force input. Use the area of a grid and water storage to get a 
volume. With density get a the mass, then with gravity acceleration the force from 
the water load at the grid cell is known

rlon - longitude of observation points to calculate strains
rlat - latitude of observation points to calculate strains
The observation points are output to a file. This is used with the results file with has 
a coordinate system in meters relative to the first observatoin point. The order is 
consistent and the observationPoints.txt is the geocorrdinate location


'''


def make_input_file(self):
    # stat2A_infile input file
    f = open(self.filename, 'w')

    # Add executable and fault params - this is a 90 dip surface load
    print('#! /bin/bash', file=f)
    print('', file=f)
    print('stat2A_infile << ! > /dev/null', file=f)
    fout = str(self.filename).replace('in','out')
    print(fout, file=f)  # This requires the stat2A source code to change outfile name
    print('0.1 0.001 90.0', file=f)

    # meters between points
    dlon =  self.dlon*111.11*1e3  #np.gradient(self.lon)*111.11*1e3 
    dlat =  self.dlat*111.11*1e3  #np.gradient(self.lat)*111.11*1e3
    area = dlon * dlat
    dz   = self.meterH2O # water loss is positive force upward.
    force = area * dz * self.rho * self.g
    
    # plot the input data
    if self.plot:
        fig, ax = plt.subplots()
        sc = ax.scatter(self.lon, self.lat, s=10, c=-dz, edgecolor='', cmap=plt.cm.seismic, vmin=-1., vmax=1.)
        divider1 = make_axes_locatable(ax)
        cax = divider1.append_axes("right", size="5%", pad=0.05)
        cbar = fig.colorbar(sc, cax=cax)
        cbar.set_label('Water (m)', fontsize=10)
        fig.savefig(self.filename + '.png', bbox_inches='tight')
        plt.close('all')
    
    # keep only load points with a force
    ndx_nonzero = np.abs(force) > 0.
    
    # print all lines open file with map function for input string
    N = np.sum(ndx_nonzero)
    print('{0:5.0f}'.format(N), file=f)
    if N > 0:
        val = np.array([self.lat, self.lon, force]).T[ndx_nonzero]
        for line in map(lat_lon_force_str, val):
            print(line, file=f)
    print('', file=f)
    # Receiver points for deformation calculations
    # First line is total number of node points
    print('{0:8.0f}'.format(len(self.rlon)), file=f)
    f2 = open('observationPoints.txt','w')
    val = np.array([self.rlat, self.rlon]).T
    for line in map(lat_lon_receiver, val):
        print(line, file=f)
        print(line, file=f2)
    print('!', file=f)
    f.close()
    f2.close()


def lat_lon_force_str(args):
    ''' string for surface load force '''
    return '{0:10.3f} {1:10.3f} 1.0 0.0 0.0  {2:12.6e}'.format(args[0], args[1], args[2]) 

def lat_lon_receiver(args):
    ''' string for receiver locations'''
    return '{0:10.5f}  {1:10.5f}'.format(args[0], args[1])

