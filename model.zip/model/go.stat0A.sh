#! /bin/bash

# Make all Greens functions at once. Copy back to stat0.out when 
# running model

cp earth.modelPREM earth.model_stat

lmax=3200
depths='8 15'
for dep in ${depths}; do
echo $dep km
stat0A_vload << ! > /dev/null
2 ${lmax}
2. 0.
${dep}
!
sleep 2
mv stat0.out ${dep}.0km-${lmax}-stat0.out
sleep 5

done
