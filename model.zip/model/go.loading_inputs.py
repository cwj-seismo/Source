#! /usr/bin/env python

import glob
# import numpy as np
# import matplotlib.pyplot as plt
# import py_func
import os
import shutil
import multiprocessing
import subprocess as sub

def go(cmd):
	sub.call('sh ' +cmd, shell=True)

pwd = os.getcwd()
os.chdir('/work/thidwick/tecton/Chris_new/Seasonal_Loading/Loading_input/Loading_input_Argus')
path = '2*.in'
go_list = glob.glob(path)

path2 = '/work/thidwick/tecton/Chris_new/Seasonal_Loading/Loading_input/stat0A_suite/'
shutil.copy(path2 + 'stat0.out-3200-8.0km-PREM', 'stat0.out')

''' Setup multi core '''
N_cpu = 12 # multiprocessing.cpu_count() / 2 # Only physical cores, so use half 
print( " Using " + str(N_cpu) + " cores")
pool = multiprocessing.Pool(processes=N_cpu)
print( ' Enter multiprocessing. Kill shell to interupt, ctrl-C does not work!')
pool.map(go, go_list)
pool.close() # We are not adding any more processes to the pool
pool.join() # We are joining the pool

